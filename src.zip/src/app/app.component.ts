import { Component } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { FormGroup, FormBuilder, Validators, Form } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'sampleproject';
  OTP;
  subscription: Subscription;
  formEle: FormGroup;
  formEle1: FormGroup;
  RegisterForm:FormGroup;
  otpFlag:boolean = false;
  GotpFlag:boolean = true;
  msgFlag:boolean = false;
  contentFlag:boolean = false;
  displayFlag:boolean = false;
  key: string ="user" ;
  myItem: string;

  constructor(private fb: FormBuilder,private _snackBar: MatSnackBar) { }
  ngOnInit() {
    this.formEle = this.fb.group({
      Mobile: [null,Validators.required]
    });
    this.formEle1 = this.fb.group({
      otp: [null,Validators.required]
    });
    this.RegisterForm = this.fb.group({
      Mobile:[null,Validators.required]
    })
    // localStorage.setItem(this.key, '8977107177');
    // this.myItem = localStorage.getItem(this.key);
    // console.log("mynumberoninit",this.myItem);
    // console.log(localStorage);
  }

  register(){
    if(this.RegisterForm.controls.Mobile.value){
      localStorage.setItem(this.key,this.RegisterForm.controls.Mobile.value);
      this.myItem = localStorage.getItem(this.key);
      console.log("setItems",this.myItem);
      // this.formEle.get('Mobile').patchValue(this.myItem);
    }
    this.displayFlag = true;
  }
  generateOtp() {
    this.GotpFlag = false;
    this.OTP = '';
    this.contentFlag = true;
    var digits = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var len = digits.length;
    if(this.myItem == this.formEle.controls.Mobile.value){
      this.otpFlag = true;
      this.msgFlag = true;
      for (let i = 0; i < 6; i++) {
        this.OTP += digits[Math.floor(Math.random() * len)];
      }
      console.log("otp", this.OTP);
      setTimeout(() => this.formEle1.get('otp').patchValue(this.OTP), 3000);
      setTimeout(() => this.otpFlag = false, 5000);
      setTimeout(() =>this.msgFlag = false, 3000);

    }else{
      this.otpFlag = false;
      this.GotpFlag = true;
      this.msgFlag = false;
      this.openSnackBar("Please Entered Valid MobileNumber",'Error');
    }
  
  }
  compare() {
    this.displayFlag = false;
    if(this.OTP == this.formEle1.value.otp){
      this.openSnackBar("you  entered OTP is submited successfull",'ok')
    }else{
      this.openSnackBar("Please Entered correct Otp",'Error')
    }
    this.formEle1.reset();
    this.formEle.reset();
    this.clear();
  }
  clear(){
    this.otpFlag = false;
    this.GotpFlag = true;
    this.contentFlag = false;
    this.displayFlag = false;
    this.formEle.reset();
    this.formEle1.reset();
    this.RegisterForm.reset();
  }
  ngOnDestroy() {
    this.subscription && this.subscription.unsubscribe();
  }
  showAlert(message, className) {
    var div = document.createElement('div');
    div.style.width = '200px';
    div.className = `alert alert-${className} text-primary rounded-pill mx-5 mt-5`;
    div.appendChild(document.createTextNode(message));
    var form = document.getElementById('.container');
    document.body.insertBefore(div, form);
    setTimeout(() => document.querySelector('.alert').remove(), 3000);
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
    });
  }


}

import { MobileNumberDirective } from "./commonDirective";

import { NgModule } from "@angular/core";

@NgModule({
    exports: [MobileNumberDirective],
    declarations: [ 
        MobileNumberDirective]
     
})
export class sharedDirectiveModule {

}

import { Directive, ElementRef, HostListener } from '@angular/core';

import { isNumeric } from 'rxjs/internal-compatibility';



@Directive({
    selector: '[allow-mobilenumber-nospace]'
})
export class MobileNumberDirective {

    regexStr = new RegExp(/^[0-9]*$/);
    regexP = new RegExp(/^([0-9])*$/);

    constructor(private el: ElementRef) { }
    @HostListener('keypress', ['$event']) onKeyPress(event) {
        if (event.which == 32)
            return false;
        else
            return new RegExp(this.regexStr).test(event.key);
    }
    @HostListener('paste', ['$event']) blockPaste(event: any) {
        const pastedInput: string = event.clipboardData ? event.clipboardData.getData('text/plain') : window['clipboardData'].getData('Text');
        const pastedInputw: string = (event.clipboardData ? this.el.nativeElement.value : event.target.value) + pastedInput;
        if (pastedInput.length > 15) {
            event.preventDefault();
            return false;
        }
        else if (!this.regexP.test(pastedInput) || pastedInputw.includes(' ')) {
            event.preventDefault();
            return false;
        }
    }
    @HostListener('drop', ['$event']) blockDrop(e: MouseEvent) {
        e.preventDefault();
    }
}

